# algo
Set of tools for algorithmic trading

# Building
```python -m build```

Libs are in dist
