# algo
Set of tools for algorithmic trading

# Building
```python -m build```

build on local
``` python -m build -o ../algo-release ```

Libs are in dist

TODO: 
 * make the config lazy, so user can access constants without config 
  Constants should be available are:
   * list of instruments
   * list of currently implemented strategies