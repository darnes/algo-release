# algo
Set of tools for algorithmic trading

# Building
```python -m build```

build on local
``` python -m build -o ../algo-release ```

Libs are in dist
